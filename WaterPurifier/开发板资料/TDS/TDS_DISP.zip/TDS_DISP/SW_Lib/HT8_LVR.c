/**
  ******************************************************************************
  * @file HT8_LVR.c
  * @brief This file provides all the LVR firmware functions.
  * @author Holtek Semiconductor Inc.
  * @version V1.0.0
  * @date 2020-06-15
  ******************************************************************************
  * @attention
  *
  * Firmware Disclaimer Information
  *
  * 1. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, which is supplied by Holtek Semiconductor Inc., (hereinafter referred to as "HOLTEK") is the
  *    proprietary and confidential intellectual property of HOLTEK, and is protected by copyright law and
  *    other intellectual property laws.
  *
  * 2. The customer hereby acknowledges and agrees that the program technical documentation, including the
  *    code, is confidential information belonging to HOLTEK, and must not be disclosed to any third parties
  *    other than HOLTEK and the customer.
  *
  * 3. The program technical documentation, including the code, is provided "as is" and for customer reference
  *    only. After delivery by HOLTEK, the customer shall use the program technical documentation, including
  *    the code, at their own risk. HOLTEK disclaims any expressed, implied or statutory warranties, including
  *    the warranties of merchantability, satisfactory quality and fitness for a particular purpose.
  *
  * <h2><center>Copyright (C) Holtek Semiconductor Inc. All rights reserved</center></h2>
  ************************************************************************************************************/

/* Includes ------------------------------------------------------------------*/


#include "HT8_LVR.h"



/**
  * @brief LVR initialization function.
  * @param[in] Non.
  * @retval Non.
  */
void LVR_Init()
{
#ifdef	LVR_VOLTAGE_1V7
	_lvrc = 0b01100110;	

#elif	LVR_VOLTAGE_1V9
	_lvrc = 0b01010101;
	
#elif	LVR_VOLTAGE_2V55
	_lvrc = 0b00110011;
	
#elif	LVR_VOLTAGE_3V15
	_lvrc = 0b10011001;
	
#elif	LVR_VOLTAGE_3V8
	_lvrc = 0b10101010;
	
#elif	LVR_DISABLE
	_lvrc = 0b11110000;
	
#endif
}

/******************* (C) COPYRIGHT 2019 Holtek Semiconductor Inc *****END OF FILE****/